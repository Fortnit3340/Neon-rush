# ⚡ Neon Rush - Single File Version

## 🎮 Play Now!

Just open `neon-rush.html` in your browser - no installation needed!

## 🌐 Upload to GitHub

1. Go to https://github.com/new
2. Create repository: `neon-rush`
3. Upload `neon-rush.html`
4. Go to Settings → Pages
5. Enable: Branch **main** / Folder **/(root)**
6. Wait 1-2 minutes
7. Visit: `https://YOUR-USERNAME.github.io/neon-rush/neon-rush.html`

## 🎯 Features

✅ 7 cars (C → LEGENDARY)  
✅ 3 tracks (City, Highway, Mountain)  
✅ Car customization (paint, neon, wheels)  
✅ Performance upgrades (engine, turbo, brakes, tires, handling, nitro)  
✅ Classic mode + 1v1 bot duels  
✅ Adaptive AI difficulty  
✅ Weather + day/night cycle  
✅ XP/levels, cash, shop  
✅ Achievements + daily challenges  
✅ Daily login bonus  
✅ Local save system  
✅ Mobile + PC + controller support  

## 🎮 Controls

| Desktop | Mobile |
|---------|--------|
| W/Up: Accelerate | Auto |
| S/Down: Brake | Brake button |
| A/Left: Steer left | Left button |
| D/Right: Steer right | Right button |
| Space: Boost | Boost button |

## 📝 Notes

- Single HTML file (59 KB)
- All CSS and JavaScript embedded
- Perfect for GitHub Pages
- Saves progress in browser localStorage
- Works offline

Enjoy! 🏁⚡
